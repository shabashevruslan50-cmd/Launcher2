package com.example.gamelauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager

/**
 * BootReceiver listens for the system BOOT_COMPLETED broadcast. If the user
 * enabled automatic overlay start in their preferences, the receiver will
 * launch OverlayService so the Start/Select buttons appear immediately
 * following boot.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = PreferenceManager.getDefaultSharedPreferences(context)
            val autoStart = prefs.getBoolean("pref_auto_start_overlay", false)
            if (autoStart) {
                val serviceIntent = Intent(context, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                }
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}