package com.example.gamelauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.preference.PreferenceManager

/**
 * OverlayService draws two floating buttons (Start and Select) on top of all
 * other content. The buttons are draggable and send Android keyevents when
 * tapped. Appearance such as size, transparency and colour is driven by
 * user preferences defined in SettingsActivity.
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var leftView: View? = null
    private var rightView: View? = null
    private val prefs by lazy { PreferenceManager.getDefaultSharedPreferences(this) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startOverlay()
            ACTION_STOP -> stopOverlay()
            ACTION_UPDATE_ALPHA -> {
                val alpha = intent.getFloatExtra(EXTRA_ALPHA, DEFAULT_ALPHA)
                updateAlpha(alpha)
            }
        }
        return START_STICKY
    }

    private fun startOverlay() {
        if (isRunning) return
        isRunning = true

        // Ensure we run in the foreground to avoid being killed by the system
        val notification = createForegroundNotification()
        startForeground(NOTIFICATION_ID, notification)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val inflater = LayoutInflater.from(this)
        // Retrieve appearance preferences. Size is stored in dp units; convert to pixels.
        val sizeDp = prefs.getInt(KEY_BUTTON_SIZE, DEFAULT_BUTTON_SIZE)
        val buttonSize = (sizeDp * resources.displayMetrics.density).toInt()
        val alpha = prefs.getFloat(KEY_BUTTON_ALPHA, DEFAULT_ALPHA)
        val colour = prefs.getInt(KEY_BUTTON_COLOR, DEFAULT_BUTTON_COLOR)

        // Left button: Start
        leftView = inflater.inflate(R.layout.overlay_button, null).apply {
            val img = findViewById<ImageView>(R.id.button_icon)
            img.setImageResource(android.R.drawable.ic_media_play)
            img.setColorFilter(colour, PorterDuff.Mode.SRC_IN)
            // Use the configured keycode or default
            setOnClickListener {
                emitKeyEvent(prefs.getInt(KEY_LEFT_KEYCODE, DEFAULT_LEFT_KEYCODE))
            }
            setupDrag(this)
            this.alpha = alpha
        }
        rightView = inflater.inflate(R.layout.overlay_button, null).apply {
            val img = findViewById<ImageView>(R.id.button_icon)
            img.setImageResource(android.R.drawable.ic_media_pause)
            img.setColorFilter(colour, PorterDuff.Mode.SRC_IN)
            setOnClickListener {
                emitKeyEvent(prefs.getInt(KEY_RIGHT_KEYCODE, DEFAULT_RIGHT_KEYCODE))
            }
            setupDrag(this)
            this.alpha = alpha
        }
        // Create layout params with size and initial gravity
        val leftParams = createLayoutParams(Gravity.START or Gravity.CENTER_VERTICAL).apply {
            width = buttonSize
            height = buttonSize
        }
        val rightParams = createLayoutParams(Gravity.END or Gravity.CENTER_VERTICAL).apply {
            width = buttonSize
            height = buttonSize
        }
        leftView?.let { windowManager?.addView(it, leftParams) }
        rightView?.let { windowManager?.addView(it, rightParams) }
    }

    private fun stopOverlay() {
        if (!isRunning) return
        isRunning = false
        leftView?.let { windowManager?.removeView(it) }
        rightView?.let { windowManager?.removeView(it) }
        leftView = null
        rightView = null
        stopForeground(true)
        stopSelf()
    }

    private fun updateAlpha(newAlpha: Float) {
        leftView?.alpha = newAlpha
        rightView?.alpha = newAlpha
    }

    private fun createForegroundNotification(): Notification {
        val channelId = "overlay_service"
        val channelName = "Overlay Service"
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_MIN)
            notificationManager.createNotificationChannel(channel)
        }
        val intent = Intent(this, LauncherActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.overlay_running))
            .setContentText(getString(R.string.overlay_running_desc))
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createLayoutParams(gravity: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            x = 0
            y = 0
        }
    }

    /**
     * Attaches a simple drag listener to the view. Allows the user to reposition
     * the button anywhere on screen. Updates layout params in the window manager.
     */
    private fun setupDrag(view: View) {
        val layoutParams = view.layoutParams as WindowManager.LayoutParams
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    layoutParams.x += dx.toInt()
                    layoutParams.y += dy.toInt()
                    windowManager?.updateViewLayout(v, layoutParams)
                    lastX = event.rawX
                    lastY = event.rawY
                    true
                }
                else -> false
            }
        }
    }

    /**
     * Invokes the Android input shell to simulate a key press corresponding to
     * the provided keycode. If the command fails the exception is logged.
     */
    private fun emitKeyEvent(keyCode: Int) {
        try {
            val cmd = arrayOf("input", "keyevent", keyCode.toString())
            Runtime.getRuntime().exec(cmd)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        const val ACTION_START = "com.example.gamelauncher.action.START"
        const val ACTION_STOP = "com.example.gamelauncher.action.STOP"
        const val ACTION_UPDATE_ALPHA = "com.example.gamelauncher.action.UPDATE_ALPHA"
        const val EXTRA_ALPHA = "extra_alpha"
        const val NOTIFICATION_ID = 1
        // Preference keys
        const val KEY_BUTTON_SIZE = "pref_button_size"
        const val KEY_BUTTON_ALPHA = "pref_button_alpha"
        const val KEY_BUTTON_COLOR = "pref_button_color"
        const val KEY_LEFT_KEYCODE = "pref_left_keycode"
        const val KEY_RIGHT_KEYCODE = "pref_right_keycode"
        // Default appearance values
        const val DEFAULT_BUTTON_SIZE = 80 // dp-equivalent in pixels; will be used directly
        const val DEFAULT_ALPHA = 0.8f
        const val DEFAULT_BUTTON_COLOR = Color.RED
        const val DEFAULT_LEFT_KEYCODE = 108 // KEYCODE_BUTTON_START
        const val DEFAULT_RIGHT_KEYCODE = 109 // KEYCODE_BUTTON_SELECT
        @Volatile
        var isRunning = false
        private var lastX = 0f
        private var lastY = 0f
    }
}