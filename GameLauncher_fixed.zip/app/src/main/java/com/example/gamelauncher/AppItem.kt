package com.example.gamelauncher

import androidx.annotation.DrawableRes

/**
 * Simple data container representing a launchable application entry. The
 * launcher displays a grid of these items and starts the corresponding
 * activity on click.
 *
 * @param label Human readable name shown below the icon.
 * @param packageName Package name used to resolve a launch intent.
 * @param iconResId Drawable resource for the icon.
 */
data class AppItem(
    val label: String,
    val packageName: String,
    @DrawableRes val iconResId: Int
)