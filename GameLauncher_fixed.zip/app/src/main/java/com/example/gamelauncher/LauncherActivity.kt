package com.example.gamelauncher

import android.app.ActivityInfo
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * LauncherActivity serves as the home screen replacement. It displays a grid of
 * launchable applications (for now a single Moonlight entry) and provides
 * access to the settings screen. It also starts the overlay service on
 * creation so that the Start/Select buttons are available across the system.
 */
class LauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)

        // Start the overlay service; ACTION_START ensures the overlay is created
        val svcIntent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
        }
        startService(svcIntent)

        // Configure the grid of app shortcuts
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val spanCount = 3 // three icons per row
        recyclerView.layoutManager = GridLayoutManager(this, spanCount)
        val apps = listOf(
            AppItem(
                label = getString(R.string.moonlight_label),
                packageName = "com.limelight",
                iconResId = R.drawable.gamepad_red
            )
            // Additional entries can be added here
        )
        recyclerView.adapter = AppAdapter(this, apps)

        // Navigate to settings when tapping the cog icon
        val settingsButton = findViewById<ImageButton>(R.id.settingsButton)
        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Apply orientation lock based on user preference
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val landscapeOnly = prefs.getBoolean("pref_landscape_only", true)
        requestedOrientation = if (landscapeOnly) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}