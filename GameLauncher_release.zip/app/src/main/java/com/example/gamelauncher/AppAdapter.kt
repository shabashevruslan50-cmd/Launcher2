package com.example.gamelauncher

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

/**
 * RecyclerView.Adapter that binds a list of AppItem instances to a simple
 * item view. When an item is tapped, the corresponding package is launched
 * via PackageManager. If the package cannot be found, a toast is shown.
 */
class AppAdapter(
    private val context: Context,
    private val items: List<AppItem>
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.appIcon)
        val label: TextView = itemView.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.icon.setImageResource(item.iconResId)
        holder.label.text = item.label
        // Apply icon size preference to each icon. We read preferences here so
        // that changes in SettingsActivity reflect on the next bind call.
        // Retrieve icon size in dp and convert to pixels for actual view dimensions
        val prefs = androidx.preference.PreferenceManager.getDefaultSharedPreferences(context)
        val sizeDp = prefs.getInt("pref_icon_size", 80)
        val sizePx = (sizeDp * context.resources.displayMetrics.density).toInt()
        holder.icon.layoutParams.width = sizePx
        holder.icon.layoutParams.height = sizePx
        holder.icon.requestLayout()
        holder.itemView.setOnClickListener {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(item.packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
            } else {
                Toast.makeText(
                    context,
                    context.getString(R.string.app_not_found),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun getItemCount(): Int = items.size
}