package com.example.gamelauncher

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager

/**
 * SettingsActivity allows the user to customise aspects of the launcher and
 * overlay buttons. Adjustments are persisted to SharedPreferences and
 * applied immediately by restarting the overlay service. The available
 * preferences include button size, transparency, colour, icon size and
 * orientation lock.
 */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val editor = prefs.edit()

        val seekButtonSize = findViewById<SeekBar>(R.id.seekButtonSize)
        val seekButtonAlpha = findViewById<SeekBar>(R.id.seekButtonAlpha)
        val radioColor = findViewById<RadioGroup>(R.id.radioColor)
        val seekIconSize = findViewById<SeekBar>(R.id.seekIconSize)
        val switchOrientation = findViewById<Switch>(R.id.switchOrientation)

        // Initialise controls with current preference values
        val btnSize = prefs.getInt("pref_button_size", OverlayService.DEFAULT_BUTTON_SIZE)
        seekButtonSize.progress = btnSize
        val alphaPercent = (prefs.getFloat("pref_button_alpha", OverlayService.DEFAULT_ALPHA) * 100).toInt()
        seekButtonAlpha.progress = alphaPercent
        val colour = prefs.getInt("pref_button_color", OverlayService.DEFAULT_BUTTON_COLOR)
        when (colour) {
            Color.RED -> radioColor.check(R.id.colorRed)
            Color.BLUE -> radioColor.check(R.id.colorBlue)
            Color.GREEN -> radioColor.check(R.id.colorGreen)
            else -> radioColor.check(R.id.colorRed)
        }
        val iconSize = prefs.getInt("pref_icon_size", 80)
        seekIconSize.progress = iconSize
        val lockLandscape = prefs.getBoolean("pref_landscape_only", true)
        switchOrientation.isChecked = lockLandscape

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            // Persist values from controls
            editor.putInt("pref_button_size", seekButtonSize.progress)
            editor.putFloat("pref_button_alpha", seekButtonAlpha.progress / 100f)
            // Determine selected colour
            val selectedId = radioColor.checkedRadioButtonId
            val selectedColour = when (selectedId) {
                R.id.colorRed -> Color.RED
                R.id.colorBlue -> Color.BLUE
                R.id.colorGreen -> Color.GREEN
                else -> Color.RED
            }
            editor.putInt("pref_button_color", selectedColour)
            editor.putInt("pref_icon_size", seekIconSize.progress)
            editor.putBoolean("pref_landscape_only", switchOrientation.isChecked)
            editor.apply()

            // Restart overlay service to apply new look
            val stopIntent = Intent(this, OverlayService::class.java).apply { action = OverlayService.ACTION_STOP }
            startService(stopIntent)
            val startIntent = Intent(this, OverlayService::class.java).apply { action = OverlayService.ACTION_START }
            startService(startIntent)
            finish()
        }
    }
}